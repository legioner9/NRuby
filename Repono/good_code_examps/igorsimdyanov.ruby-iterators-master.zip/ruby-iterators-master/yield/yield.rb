def iterator
  yield 'hello'
  yield 'world'
end
