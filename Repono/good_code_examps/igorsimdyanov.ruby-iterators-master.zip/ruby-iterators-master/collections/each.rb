[1, 2, 3, 4, 5].each { |x| puts x + 1 }
