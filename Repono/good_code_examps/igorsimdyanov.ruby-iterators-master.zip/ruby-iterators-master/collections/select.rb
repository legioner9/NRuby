[1, 2, 3, 4, 5].select { |x| x.even? }
[1, 2, 3, 4, 5].find_all { |x| x.even? }
