[1, 2, 3, 4, 5].reduce { |fact, x| fact * x }
[1, 2, 3, 4, 5].inject { |fact, x| fact * x }
