[1, 2, 3, 4, 5].reject { |x| x.even? }
[1, 2, 3, 4, 5].delete_if { |x| x.even? }