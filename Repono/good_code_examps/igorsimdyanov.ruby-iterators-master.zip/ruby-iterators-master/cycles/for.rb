for el in [1, 2, 3, 4, 5] do
  puts el
end
