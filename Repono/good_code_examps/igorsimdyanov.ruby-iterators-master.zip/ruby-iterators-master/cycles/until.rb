i = 1
until i > 5 do
  puts i
  i += 1
end
