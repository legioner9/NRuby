i = 1
while i <= 5 do
  puts i
  i += 1
end
