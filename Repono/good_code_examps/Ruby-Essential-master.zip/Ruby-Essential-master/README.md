# Ruby essential

The repository consist of Ruby Basics.

# Topics cover 
- Introduction
- Installation
- Object Types
- Control Structure
- Loops
_ Iterators
- Code Blocks
- Methods
- Classes
- Modules
- Working with Files

