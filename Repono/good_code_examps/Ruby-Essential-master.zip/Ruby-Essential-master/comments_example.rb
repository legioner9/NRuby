# single line comment  (using hash sign)

puts 500
# print doesnot return a line return
print 300
puts 388

=begin

for mult-line comments use equal to begin and equal to end 

.....
....
...
=end

puts "Hello"
puts "World"