1.upto(5) do |num|
  puts "Hello " + num.to_s
end