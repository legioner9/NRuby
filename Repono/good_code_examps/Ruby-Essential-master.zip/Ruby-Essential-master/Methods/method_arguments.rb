# methods with arguments  typically use parenthesis
# methods  without arguments typically  donot.
# Parenthesis are optional on both cases

def welcome(name)
    puts"Hello #{name}"
end 

# calling method
welcome("World")
welcome("Mary")
welcome "Fred"