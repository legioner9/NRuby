puts 123
# print does not add a line return 
print 564
puts 121
