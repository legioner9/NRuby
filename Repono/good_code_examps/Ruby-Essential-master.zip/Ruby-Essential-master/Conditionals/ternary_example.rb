=begin
ternary operator:syntax

boolean ? code1 : code2

=end

x=1
puts x==1? "one" : "not one"