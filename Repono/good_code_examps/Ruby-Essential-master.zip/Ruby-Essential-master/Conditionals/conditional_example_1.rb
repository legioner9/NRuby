name="Steve"
if name == "Steve"
   puts "Found Steve"
else
   puts "not Steve"
end