# example of conditional statements
#x=56 first execution
x=17  # seconf execution
if x<=10
  puts "less than and equal to 10"
elsif x >=20
  puts "greater than and equal to 20"
else
puts "numbers are between 11 and 19"
end
