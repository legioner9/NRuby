=begin
syntax for unless:

unless boolean
...
end

=end
x = 1 
unless x == 2
  puts "x is not 2"
end