x=0
loop do     # like for loop
  x += 2    # increment by 2
  break if x >= 20     # terminate from loop if x>=20
  puts x    # print the values of x
end