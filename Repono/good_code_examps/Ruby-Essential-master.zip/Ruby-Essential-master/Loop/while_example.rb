x = 0
while x < 20
  x += 2
  puts x
end