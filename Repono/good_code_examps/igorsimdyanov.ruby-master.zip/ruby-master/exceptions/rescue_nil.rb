arr = []
result = arr[:hello][:world] rescue nil
