raise 'Ошибка'
fail 'Ошибка'
