raise 'Ошибка'
raise RuntimeError, 'Ошибка'
raise RuntimeError.new('Ошибка')
raise RuntimeError.exception('Ошибка')
