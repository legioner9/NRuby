puts 2 / 0
