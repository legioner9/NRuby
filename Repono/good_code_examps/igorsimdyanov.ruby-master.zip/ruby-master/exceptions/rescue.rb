begin
  raise 'Ошибка'
rescue
  puts 'Произошла ошибка'
end
