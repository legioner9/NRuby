File.open('hello.txt') do |file|
  p file.read
end
