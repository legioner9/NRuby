puts File.size('hello.txt') # 90
