file = File.new('hello.txt', 'w')
p file #<File:hello.txt>
