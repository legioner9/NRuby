puts 'Hello, world!'        # Hello, world!
STDOUT.puts 'Hello, world!' # Hello, world!
STDERR.puts 'Ошибка'        # Ошибка
