File.rename('hello.txt', 'new_hello.txt')
