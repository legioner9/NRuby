file = File.new('hello.txt', 'w')
puts file.fileno # 10
