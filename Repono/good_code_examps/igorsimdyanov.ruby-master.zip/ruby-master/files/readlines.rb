arr = File.readlines('hello.txt')
p arr
