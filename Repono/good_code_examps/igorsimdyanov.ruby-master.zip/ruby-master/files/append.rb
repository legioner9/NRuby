file = File.new('hello.txt', 'a')
file.puts 'Hello, world!'
