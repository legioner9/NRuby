arr = File.readlines('hello.txt').map(&:chomp)
p arr
