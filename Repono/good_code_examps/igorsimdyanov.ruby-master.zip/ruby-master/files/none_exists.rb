file = File.new('none_exists.txt', 'r')
# No such file or directory @ rb_sysopen - none_exists.txt
