File.open('hello.txt', 'w') do |file|
  file.puts 'Цена билета: 500'
  file.puts 'Дата: 2019.10.10 20:20'
  file.puts 'Место: 3 ряд, 10 место'
end
