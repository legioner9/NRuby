File.unlink('hello.txt')
