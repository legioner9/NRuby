p File.read('hello.txt')
