arr = File.readlines('hello.txt', chomp: true)
p arr
