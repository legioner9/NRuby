file = File.new('hello.txt', 'a+b')
file = File.new('hello.txt', 'rb')
file = File.new('hello.txt', 'wb')
