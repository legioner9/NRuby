File.write('hello.txt', 'Hello, world!')
