file = File.new('hello.txt', 'a+t')
file = File.new('hello.txt', 'rt')
file = File.new('hello.txt', 'wt')
