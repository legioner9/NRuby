rainbow = %w[red orange yellow green gray indigo violet]

rainbow.each_with_index { |color, i| puts "#{i}: #{color}" }
