rainbow = %w[red orange yellow green gray indigo violet]

rainbow.each { |color| puts color }
