5.upto(10) { |i| puts i }
