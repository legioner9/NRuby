5.times { |i| puts i }
