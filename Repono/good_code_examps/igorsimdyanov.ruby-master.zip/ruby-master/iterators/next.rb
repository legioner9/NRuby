[*1..10].each do |i|
  next if i.even?
  puts i
end
