rainbow = %w[red orange yellow green gray indigo violet]

for color in rainbow
  puts color
end
