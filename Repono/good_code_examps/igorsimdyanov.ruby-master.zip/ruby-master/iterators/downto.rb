10.downto(5) { |i| puts i }
