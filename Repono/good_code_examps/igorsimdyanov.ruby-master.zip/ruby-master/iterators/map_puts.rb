result = [1, 2, 3, 4, 5].map { |x| puts x + 1 }
p result # [nil, nil, nil, nil, nil]
