arr = [1, 2, 3, 4, 5]

result = arr.each { |x| puts x + 1 }

p result # {:per_page=>10, :page=>1}
