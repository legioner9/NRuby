arr = []
[1, 2, 3, 4, 5].each { |x| arr << x * x }
p arr # [1, 4, 9, 16, 25]
