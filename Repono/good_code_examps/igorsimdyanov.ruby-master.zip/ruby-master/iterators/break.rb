[*1..10].each do |i|
  break if i > 5
  puts i
end
