p Dir.entries '..' # [".", "..", "arrays", ...]
