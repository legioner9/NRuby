require 'fileutils'

FileUtils.mkdir_p('hello/world')
