puts Dir.pwd                                  # /home/igor/catalogs"
puts Dir.getwd                                # /home/igor/catalogs"
puts File.dirname(File.expand_path(__FILE__)) # /home/igor/catalogs"
