p Dir['*.rb'] # ["chdir.rb", ...]
