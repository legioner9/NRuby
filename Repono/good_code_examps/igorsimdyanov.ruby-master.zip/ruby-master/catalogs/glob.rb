p Dir.glob('*') # ["chdir.rb", ...]
