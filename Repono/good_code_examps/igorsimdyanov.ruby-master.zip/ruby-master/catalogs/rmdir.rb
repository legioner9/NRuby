Dir.rmdir('test')
