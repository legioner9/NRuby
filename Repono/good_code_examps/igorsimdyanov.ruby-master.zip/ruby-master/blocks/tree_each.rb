require_relative 'tree'

TREE.each { |x| p x }
