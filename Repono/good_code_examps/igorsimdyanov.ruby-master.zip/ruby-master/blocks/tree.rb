TREE = [
  'index.rb',
  {
    'src' =>  [
      'file01.rb',
      'file02.rb',
      'file03.rb',
    ]
  },
  {
    'doc' => [
      'file01.md',
      'file02.md',
      'file03.md',
      {
        'details' => [
          'index.md',
          'arch.md'
        ]
      }
    ]
  }
]
