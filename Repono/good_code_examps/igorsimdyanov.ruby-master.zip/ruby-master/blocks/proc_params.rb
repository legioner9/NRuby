pr = proc do |fst, snd, thd|
      p fst
      p snd
      p thd
    end

pr.call('first')
