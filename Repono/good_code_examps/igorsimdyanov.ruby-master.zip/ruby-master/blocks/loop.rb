loop { puts 'Hello, world!' }
