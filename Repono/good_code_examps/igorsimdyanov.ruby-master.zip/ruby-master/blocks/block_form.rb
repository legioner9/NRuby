loop { puts 'Hello, world!' }
loop do
  puts 'Hello, world!'
end
