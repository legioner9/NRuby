p( [1, 2, 3, 4, 5].map do |x| x * x end )

arr = [1, 2, 3, 4, 5].map do |x|
        x * x
      end
p arr
