CONST = 1
hello = 'Hello, world!'
