require './imports'

puts CONST # 1
puts hello # undefined local variable or method `hello'
