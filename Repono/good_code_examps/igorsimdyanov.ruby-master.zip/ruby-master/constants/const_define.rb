def hello
  COUNT = 1
end

hello
