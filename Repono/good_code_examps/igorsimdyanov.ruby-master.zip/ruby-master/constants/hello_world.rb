class HelloWorld
  def greeting
    puts 'Hello, world!'
  end
end
