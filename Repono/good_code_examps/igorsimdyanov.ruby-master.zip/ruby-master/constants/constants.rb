CONST = 12
puts CONST        # 12
puts RUBY_VERSION # 2.6.0
