puts DATA.read

__END__
Hello, world!