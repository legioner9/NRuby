t = Time.mktime(2019, 10, 31, 21, 30, 15)
p t.to_a
