puts __FILE__ # line_and_file.rb
puts __LINE__ # 2
