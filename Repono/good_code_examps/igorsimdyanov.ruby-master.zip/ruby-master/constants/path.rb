p ENV['PATH']
