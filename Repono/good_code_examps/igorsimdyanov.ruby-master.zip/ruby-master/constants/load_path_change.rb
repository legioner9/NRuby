$LOAD_PATH << '.'
require 'imports'

puts CONST # 1
