require 'date'

p Date.new
