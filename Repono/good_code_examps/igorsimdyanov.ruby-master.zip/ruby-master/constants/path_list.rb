puts ENV['PATH'].split(':')
