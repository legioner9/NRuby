require './hello_world'

hello = HelloWorld.new
hello.greeting # Hello, world!
