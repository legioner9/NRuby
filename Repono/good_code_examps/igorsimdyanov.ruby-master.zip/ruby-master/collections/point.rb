class Point
  attr_accessor :x, :y

  def initialize(x=nil, y=nil)
    @x = x
    @y = y
  end
end
