Point = Struct.new(:x, :y, keyword_init: true)
