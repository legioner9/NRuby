require_relative 'point'

fst = Point.new(3, 4)
p fst #<Point:0x00007fa833841358 @x=3, @y=4>

snd = Point.new
p snd #<Point:0x00007fa8338411a0 @x=nil, @y=nil>
