Point = Struct.new(:x, :y)
