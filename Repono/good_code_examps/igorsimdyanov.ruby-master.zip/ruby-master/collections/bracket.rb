require 'set'

p Set['saturday', 'sunday'] # #<Set: {"saturday", "sunday"}>
