require 'set'

p Set['saturday', 'sunday'].to_a # ["saturday", "sunday"]
