require 'set'

p Set.ancestors # [Set, Enumerable, Object, Kernel, BasicObject]
