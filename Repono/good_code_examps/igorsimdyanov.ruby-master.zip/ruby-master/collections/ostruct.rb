require 'ostruct'

point = OpenStruct.new x: 3, y: 4
p point #<OpenStruct x=3, y=4>
