require_relative 'struct_point'

point = Point.new(3, 4)

p point.members # [:x, :y]
