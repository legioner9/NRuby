print 'Введите, пожалуйста, строку '
val = gets.chomp
p val
