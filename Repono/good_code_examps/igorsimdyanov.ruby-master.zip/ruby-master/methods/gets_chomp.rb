print 'Введите, пожалуйста, строку '
val = gets(chomp: true)
p val
