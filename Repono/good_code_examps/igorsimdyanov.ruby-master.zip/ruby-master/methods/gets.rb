val = gets
