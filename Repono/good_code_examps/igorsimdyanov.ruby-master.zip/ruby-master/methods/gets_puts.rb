puts 'Введите, пожалуйста, число '
val = gets
p val
