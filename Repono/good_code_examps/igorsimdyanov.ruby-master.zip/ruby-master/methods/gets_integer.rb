print 'Введите, пожалуйста, число '
val = gets.to_i
p val
