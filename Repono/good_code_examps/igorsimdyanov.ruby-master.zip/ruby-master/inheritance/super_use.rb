require_relative 'super'

news = News.new title: 'Страница',
                body: 'Тело страницы',
                keywords: ['Базовая страница']

p news
