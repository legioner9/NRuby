# class Page
#   attr_accessor :title, :body, :keywords
# end

class Page < Object
  attr_accessor :title, :body, :keywords
end
