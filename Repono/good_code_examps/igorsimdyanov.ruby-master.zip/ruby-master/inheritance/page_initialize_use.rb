require_relative 'page_initialize'

page = Page.new title: 'Страница',
                body: 'Тело страницы',
                keywords: ['Базовая страница']

p page
