require_relative 'page'

class PhotoCatalog < Page
  attr_accessor :photos
end
