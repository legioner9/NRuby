require_relative 'page'

class About < Page
  attr_accessor :phones, :address
end
