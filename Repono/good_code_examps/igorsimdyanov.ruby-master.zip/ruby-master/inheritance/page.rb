class Page
  attr_accessor :title, :body, :keywords
end
