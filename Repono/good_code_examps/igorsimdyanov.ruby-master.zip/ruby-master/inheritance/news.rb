require_relative 'page'

class News < Page
  attr_accessor :date
end
