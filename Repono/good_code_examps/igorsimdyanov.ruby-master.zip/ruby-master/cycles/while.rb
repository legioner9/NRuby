while true
  puts 'Hello, world!'
end
