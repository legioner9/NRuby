print 'Пожалуйста, введите количество повторов: '
max_iterates = gets.to_i
i = 0

puts 'Hello, world!' while (i += 1) <= max_iterates
