for x in 1..4
  puts x
end
