for x in [1, 2, 3, 4]
  puts x
end
