class HelloWorld
  def self.greeting # HelloWorld.greeting
    'Hello, world!'
  end
end

puts HelloWorld.greeting # Hello, world!
