class Storage
  attr_accessor :params

  def initialize
    @params = {}
  end
end
