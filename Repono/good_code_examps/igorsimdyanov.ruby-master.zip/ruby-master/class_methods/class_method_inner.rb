class HelloWorld
  def HelloWorld.greeting
    'Hello, world!'
  end
end

puts HelloWorld.greeting # Hello, world!