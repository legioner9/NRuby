n = 0
arr = Array.new(10) do
        n += 1
        n * 10
      end

p arr # [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]