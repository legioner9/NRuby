require_relative 'storage_init'

s = Storage.new
s.hello = 'world'
p s.params
