class HelloWorld
  class << self
    def greeting
      'Hello, world!'
    end
  end
end

puts HelloWorld.greeting # Hello, world!
