class Ticket
  def initialize(price)
    @price = price
  end

  def price
    @price
  end
end
