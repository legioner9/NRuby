if RUBY_VERSION == '2.5.3' then
  puts 'Содержимое if-конструкции'
end
