var = if rand(0..1) == 0
        100
      else
        200
      end

var = rand(0..1) == 0 ? 100 : 200

puts var
