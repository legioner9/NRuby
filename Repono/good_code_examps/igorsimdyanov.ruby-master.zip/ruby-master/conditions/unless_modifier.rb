puts 'Не корректная версия' unless RUBY_VERSION == '2.4.0'
