item ||= begin
  x = 12 - 5
  y = 15 - 2
  sum = x * x + y * y
  sum ** 0.5
end

puts item
