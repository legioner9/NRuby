if x = 1
  y = 'hello'
end
puts x # 1
puts y # hello
