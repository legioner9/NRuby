var = nil

if var.nil? == true
  puts 'Переменная не инициализирована'
end
