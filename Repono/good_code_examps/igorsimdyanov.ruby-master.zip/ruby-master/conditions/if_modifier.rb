puts 'Содержимое if-конструкции' if RUBY_VERSION == '2.5.3'
