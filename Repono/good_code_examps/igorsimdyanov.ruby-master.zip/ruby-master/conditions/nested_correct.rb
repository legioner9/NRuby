flag1 = true
flag2 = true

if flag1 && flag2
  puts 'Оба флага истинны'
else
  puts 'Условие: false (Один из флагов ложен)'
end
