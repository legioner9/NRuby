number = rand(0..2)

case number
when 0
  puts 'Ноль';
when 1
  puts 'Единица'
else
  puts 'Два'
end
