if false
  y = 'Hello, world!'
end
p y # nil
p z # undefined local variable or method `z' for main:Object (NameError)
