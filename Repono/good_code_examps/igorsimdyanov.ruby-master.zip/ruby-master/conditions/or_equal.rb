item = nil

item ||= 'world'
puts "Hello, #{item}!" # Hello, world!

item ||= 'Ruby'
puts "Hello, #{item}!" # Hello, world!
