if RUBY_VERSION == '2.5.3' puts 'Содержимое if-конструкции' end
