if !!Object == true
  puts 'Object - это истина'
end
