puts (if RUBY_VERSION == '2.5.3'
       'Корректная версия'
     else
       'Некорректная версия'
     end)
