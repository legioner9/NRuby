if RUBY_VERSION == '2.5.3'
  puts 'Корректная версия Ruby'
else
  puts 'Некорректная версия Ruby'
end
