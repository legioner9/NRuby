if RUBY_VERSION == '2.5.3'
  var = 'Корректная версия'
else
  var = 'Некорректная версия'
end

puts var
