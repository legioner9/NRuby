if not RUBY_VERSION == '2.4.0'
  puts 'Не корректная версия'
end
