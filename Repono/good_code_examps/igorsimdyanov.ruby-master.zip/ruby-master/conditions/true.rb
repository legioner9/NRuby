var = nil

if var.nil?
  puts 'Переменная не инициализирована'
end

if Object
  puts 'Object - это истина'
end
