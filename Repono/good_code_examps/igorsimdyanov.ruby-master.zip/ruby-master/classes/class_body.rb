class HelloWorld
  puts 'Начало класса HelloWorld'
  puts 'Завершение класса HelloWorld'
end

hello = HelloWorld.new
p hello
