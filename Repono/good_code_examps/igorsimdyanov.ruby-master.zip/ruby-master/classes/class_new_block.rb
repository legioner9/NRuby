HelloWorld = Class.new do
  def say
    'hello'
  end
end

hello = HelloWorld.new

puts hello.say # hello
