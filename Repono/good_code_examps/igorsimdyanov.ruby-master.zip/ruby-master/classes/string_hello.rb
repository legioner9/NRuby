class String
  def hello
    "Hello, #{self}!"
  end
end

puts 'world'.hello # Hello, world!
puts 'Ruby'.hello  # Hello, Ruby!
puts 'Igor'.hello  # Hello, Igor!
