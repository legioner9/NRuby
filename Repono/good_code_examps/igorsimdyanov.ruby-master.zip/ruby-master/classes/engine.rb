require_relative 'car'

engine = Car::Engine.new

puts engine.cylinders # 6
puts engine.volume    # 3
puts engine.power     # 250
