require_relative 'hello_world'

hello = HelloWorld.new
p hello # #<HelloWorld:0x007ff20606dab0>
