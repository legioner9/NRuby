HelloWorld = Class.new

hello = HelloWorld.new

p hello # #<HelloWorld:0x00007ffce40e38f8>
