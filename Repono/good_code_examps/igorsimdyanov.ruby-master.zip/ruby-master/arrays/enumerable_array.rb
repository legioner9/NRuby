arr = [1, 2, 3, 4, 5]

p arr.select(&:even?) # [2, 4]
p arr.max # 5
