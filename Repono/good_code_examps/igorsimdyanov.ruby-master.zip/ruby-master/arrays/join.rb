arr = [1, 2, 3, 4, 5]

puts arr.join     # 12345
puts arr.join '-' # 1-2-3-4-5
