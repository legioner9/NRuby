arr = [*1..21]
arr.each_slice(7) { |a| p a }
