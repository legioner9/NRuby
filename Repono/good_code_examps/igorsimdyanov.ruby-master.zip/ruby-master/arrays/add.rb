arr = []
arr << 1
arr << 2
arr << 3

p arr # [1, 2, 3]
