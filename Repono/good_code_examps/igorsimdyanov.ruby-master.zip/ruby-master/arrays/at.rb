arr = [1, 2, 3, 4, 5]

puts arr.at(2)  # 3
puts arr.at(-2) # 4
