matrix = [
  [1, 2, 3],
  [4, 5, 6]
]

p matrix.transpose # [[1, 4], [2, 5], [3, 6]]
