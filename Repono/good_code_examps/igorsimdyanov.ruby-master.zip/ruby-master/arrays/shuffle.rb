arr = [1, 2, 3, 4, 5]

p arr.shuffle  # [4, 2, 1, 5, 3]
p arr          # [1, 2, 3, 4, 5]
p arr.shuffle! # [2, 1, 4, 5, 3]
p arr          # [2, 1, 4, 5, 3]
