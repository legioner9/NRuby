arr = [1, 2, 3, 4, 5]

p arr.sample    # 5
p arr.sample(2) # [4, 1]
