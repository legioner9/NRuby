puts [false, false, false].any? # false
puts [false, false, true].any?  # true
puts Array.new(5).any?          # false
puts [1, 2, 3, 4, 5].any?       # true
