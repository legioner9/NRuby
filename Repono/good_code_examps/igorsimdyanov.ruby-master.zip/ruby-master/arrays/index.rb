colors = %w[red orange yellow green red blue red indigo red violet]

p colors.index('red')   # 0
p colors.index('hello') # nil
p colors.rindex('red')  # 8
