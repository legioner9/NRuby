arr = [1, 2, 3, 4, 5]

p arr.include? 3  # true
p arr.include? 10 # false
