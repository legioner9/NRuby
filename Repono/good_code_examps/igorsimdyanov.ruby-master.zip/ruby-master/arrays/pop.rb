arr = [*1..5]

p arr.pop # 5
p arr.pop # 4

p arr     # [1, 2, 3]
