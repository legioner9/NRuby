arr = [1, 2, 3, 4, 5]

puts arr.reduce(:*) # 120
puts arr.reduce(:+) # 15
