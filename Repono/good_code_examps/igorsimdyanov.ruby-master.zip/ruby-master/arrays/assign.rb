arr = []
arr[0] = 1
arr[1] = 2
arr[2] = 3

p arr # [1, 2, 3]
