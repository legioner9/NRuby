puts [1, 2, 3, 4, 5].sum # 15
