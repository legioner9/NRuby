arr = [1, 2, 3, 4, 5]

p arr.take(3) # [1, 2, 3]
