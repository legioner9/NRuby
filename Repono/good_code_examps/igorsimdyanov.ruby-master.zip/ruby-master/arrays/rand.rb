colors = %w[red orange yellow green blue indigo violet]

index = rand(0..6)

puts index         # 2
puts colors[index] # yellow
