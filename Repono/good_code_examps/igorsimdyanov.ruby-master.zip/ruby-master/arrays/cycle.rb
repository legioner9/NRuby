arr = [1, 2, 3]

arr.cycle(2) { |x| puts x } # 1, 2, 3, 1, 2, 3
