eng = %i[red orange yellow green blue indigo violet]
rus = %w[красный оранжевый желтый зеленый
            голубой синий фиолетовый]

p eng.zip(rus)
