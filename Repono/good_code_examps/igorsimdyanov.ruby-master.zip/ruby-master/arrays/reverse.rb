arr = [1, 2, 3, 4, 5]

p arr.reverse  # [5, 4, 3, 2, 1]
p arr          # [1, 2, 3, 4, 5]
p arr.reverse! # [5, 4, 3, 2, 1]
p arr          # [5, 4, 3, 2, 1]
