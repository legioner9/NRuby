arr = [*1..5]

p arr.pop(1) # [5]
p arr.pop(2) # [3, 4]

p arr        # [1, 2]
