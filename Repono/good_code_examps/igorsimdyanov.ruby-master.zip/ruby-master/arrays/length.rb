arr = [1, 2, 3]
arr[7] = 4

p arr        # [1, 2, 3, nil, nil, nil, nil, 4]
p arr.length # 8
p arr.size   # 8
