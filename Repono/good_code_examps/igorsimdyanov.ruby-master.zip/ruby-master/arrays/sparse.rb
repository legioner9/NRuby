arr = []
arr[9] = 1

p arr # [nil, nil, nil, nil, nil, nil, nil, nil, nil, 1]
