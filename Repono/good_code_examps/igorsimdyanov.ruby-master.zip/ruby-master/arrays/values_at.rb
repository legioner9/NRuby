arr = (1..7).to_a

p arr.values_at(1, 3, 5) # [2, 4, 6]
