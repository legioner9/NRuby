arr = [-3, -2, -1, 0, 1, 2, 3]

puts arr.index { |value| value > 0 } # 4
