puts [true, true, true].all?  # true
puts [true, false, true].all? # false
puts [1, 2, 3, 4, 5].all?     # true
puts [1, 2, nil, 4].all?      # false
