arr = [1, 2, 3, 4, 5]

arr.reverse_each { |x| puts x }
arr.reverse.each { |x| puts x }
