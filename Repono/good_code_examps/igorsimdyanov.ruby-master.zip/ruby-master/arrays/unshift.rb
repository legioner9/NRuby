arr = [1, 2, 3]
arr.unshift(0)
arr.unshift(-3, -2, -1)

p arr # [-3, -2, -1, 0, 1, 2, 3]
