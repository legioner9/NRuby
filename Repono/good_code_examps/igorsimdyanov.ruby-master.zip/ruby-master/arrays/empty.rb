first = []
second = [1, 2, 3, 4, 5]

puts 'Массив first пустой' if first.empty?   # true
puts 'Массив second пустой' if second.empty? # false
