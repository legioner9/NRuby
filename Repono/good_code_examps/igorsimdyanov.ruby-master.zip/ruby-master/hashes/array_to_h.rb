arr = [[:first, 1], [:second, 2]]
p arr.to_h # {:first=>1, :second=>2}
