h = { fst: 1, snd: 2 }

p h.keys   # [:fst, :snd]
p h.values # [1, 2]
