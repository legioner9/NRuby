h = { first: 1, second: 2 }
h.clear
p h # {}
