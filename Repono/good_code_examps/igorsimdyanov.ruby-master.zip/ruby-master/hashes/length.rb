h = { fst: 1, snd: 2, thd: 3, fth: 4 }

puts h.size   # 4
puts h.length # 4
