h = { fst: 1, snd: 2, thd: 1 }

p h.invert # {1=>:thd, 2=>:snd}
