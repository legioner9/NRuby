p Hash.new # {}
