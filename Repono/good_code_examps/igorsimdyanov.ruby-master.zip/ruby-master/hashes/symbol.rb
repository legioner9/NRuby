first = { first: 1, second: 2 }
second = { first: :fst, second: :snd }

p first  # {:first=>1, :second=>2}
p second # {:first=>:fst, :second=>:snd}
