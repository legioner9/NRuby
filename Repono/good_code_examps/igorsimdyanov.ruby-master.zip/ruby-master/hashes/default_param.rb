h = Hash.new(42)
p h.default # 42
p h[:hello] # 42
