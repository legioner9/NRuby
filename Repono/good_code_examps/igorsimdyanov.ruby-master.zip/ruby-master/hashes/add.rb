h = {}

h['hello'] = 'world'
h[:hello] = 'ruby'

p h # {"hello"=>"world", :hello=>"ruby"}
