h = { fst: 1, snd: 2 }
p h.to_a # [[:fst, 1], [:snd, 2]]
