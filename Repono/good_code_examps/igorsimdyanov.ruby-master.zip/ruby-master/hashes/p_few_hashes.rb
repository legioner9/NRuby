p 'hello', { fst: 1, snd: 2 }, first: 1, second: 2
