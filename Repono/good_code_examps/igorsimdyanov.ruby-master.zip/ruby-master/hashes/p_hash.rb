p { first: 1, second: 2 } # syntax error, unexpected ':', expecting '}'
