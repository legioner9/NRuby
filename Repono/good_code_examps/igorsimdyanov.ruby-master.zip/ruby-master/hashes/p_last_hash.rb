p({ first: 1, second: 2 }) # плохо
p(first: 1, second: 2)     # лучше
p first: 1, second: 2      # хорошо
