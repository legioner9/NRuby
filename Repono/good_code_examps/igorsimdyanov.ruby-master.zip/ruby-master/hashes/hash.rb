first = {}
second = { 'first' => 1, 'second' => 2 }

p first  # {}
p second # {"first"=>1, "second"=>2}
