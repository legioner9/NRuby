h = Hash.new(Object.new)

p h[:hello]  #<Object:0x007fcbeb0eacb8>
p h[:world]  #<Object:0x007fcbeb0eacb8>
p h[:params] #<Object:0x007fcbeb0eacb8>
