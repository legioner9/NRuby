h = { first: 1, second: 2}

p h       # {:first=>1, :second=>2}
p h.shift # [:first, 1]
p h       # {:second=>2}
