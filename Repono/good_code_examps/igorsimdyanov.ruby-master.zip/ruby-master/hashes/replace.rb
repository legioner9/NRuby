h = {}

h[:hello] = 'hello'
p h # {:hello=>"hello"}

h[:hello] = 'ruby'
p h # {:hello=>"ruby"}
