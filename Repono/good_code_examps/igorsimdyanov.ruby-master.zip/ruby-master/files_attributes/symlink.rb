File.symlink('hello.txt', 'newhello.txt')
