#!/usr/bin/env ruby
puts 'Hello, world!'
