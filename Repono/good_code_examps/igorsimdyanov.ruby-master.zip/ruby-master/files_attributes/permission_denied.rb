puts File.read('/etc/sudoers') # Permission denied @ rb_sysopen - /etc/sudoers (Errno::EACCES)
