File.chmod(0755, 'chmod.rb')
